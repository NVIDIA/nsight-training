# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

from abc import ABC, abstractmethod
from http import HTTPStatus
import functools
import json
import warnings
import docker.errors
import socket
from typing import Dict, List, Optional
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
import tornado
from jupyter_client import AsyncKernelClient
from jupyter_client.provisioning import KernelProvisionerFactory
from jupyter_client.provisioning.provisioner_base import KernelProvisionerBase
from jupyter_server.serverapp import ServerApp

from .utils import maybe_await
from .nsight_tools import NsightTool, tools
from .webrtc_container import WebRTCManager


MIN_PORT = 1024
MAX_PORT = 65535


kernel_id_to_nsight_tool: Dict[str, NsightTool] = {}
pending_restart_kernel_id_to_nsight_tool: Dict[str, Optional[NsightTool]] = {}
kernel_id_to_kc: Dict[str, AsyncKernelClient] = {}


class NsightWarning(UserWarning):
    pass


def wrap_provisioner(provisioner: KernelProvisionerBase):
    kernel_id = provisioner.kernel_id

    original_launch_kernel = provisioner.launch_kernel
    @functools.wraps(original_launch_kernel)
    async def launch_kernel(cmd: List[str], **kwargs):
        if kernel_id in pending_restart_kernel_id_to_nsight_tool:
            old_tool = kernel_id_to_nsight_tool.pop(kernel_id, None)
            if old_tool is not None:
                old_tool.cleanup()
            new_tool = pending_restart_kernel_id_to_nsight_tool.pop(kernel_id)
            if new_tool is not None:
                kernel_id_to_nsight_tool[kernel_id] = new_tool
        tool = kernel_id_to_nsight_tool.get(kernel_id)
        if tool is not None:
            cmd = tool.launch_kernel_cmd() + cmd
        return await original_launch_kernel(cmd, **kwargs)
    provisioner.launch_kernel = launch_kernel

    original_post_launch = provisioner.post_launch
    @functools.wraps(original_post_launch)
    async def post_launch(**kwargs):
        await original_post_launch(**kwargs)

        if kernel_id in kernel_id_to_kc:
            warnings.warn(NsightWarning('Kernel client already exists, stopping it'), stacklevel=2)
            kernel_id_to_kc.pop(kernel_id).stop_channels()

        kernel_id_to_kc[kernel_id] = kc = AsyncKernelClient()
        kc.load_connection_info(provisioner.connection_info)
        tool = kernel_id_to_nsight_tool.get(kernel_id)
        if tool is not None:
            await tool.post_launch(kc)
    provisioner.post_launch = post_launch

    original_cleanup = provisioner.cleanup
    @functools.wraps(original_cleanup)
    async def cleanup(*args, **kwargs):
        if kernel_id in kernel_id_to_kc:
            kernel_id_to_kc.pop(kernel_id).stop_channels()
        await original_cleanup(*args, **kwargs)
    provisioner.cleanup = cleanup


def wrap_kernel_provisioner_factory():
    original_create_provisioner_instance = KernelProvisionerFactory.create_provisioner_instance

    @functools.wraps(original_create_provisioner_instance)
    def create_provisioner_instance(*args, **kwargs):
        provisioner = original_create_provisioner_instance(*args, **kwargs)
        wrap_provisioner(provisioner)
        return provisioner

    KernelProvisionerFactory.create_provisioner_instance = create_provisioner_instance

class HandlerBase(APIHandler, ABC):
    @abstractmethod
    def post_impl(self, **kwargs):
        pass

    @tornado.web.authenticated
    async def post(self):
        try:
            await maybe_await(self.post_impl(**(self.get_json_body() or {})))
        except BaseException as e:
            self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
            self.finish(json.dumps({'message': str(e), 'type': e.__class__.__name__}))


class DoIsInsideDockerHandler(HandlerBase):
    def post_impl(self):
        self.finish(json.dumps({'inside_docker': WebRTCManager.inside_docker}))


class DoGetKernelStateHandler(HandlerBase):
    def post_impl(self, *, kernel_id: str):
        tool = kernel_id_to_nsight_tool.get(kernel_id)
        self.finish(json.dumps({'current': tool.target_exe_name() if tool is not None else None}))


class DoEnableHandler(HandlerBase):
    async def post_impl(self, *,
                  tool_type: str, kernel_id: str, args: str = '', installation_path: str = ''):
        kc = kernel_id_to_kc.get(kernel_id)
        if kc is None:
            self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
            self.finish(json.dumps({'message': 'Could not find kernel client'}))
            return

        tool = tools[tool_type](kernel_id, installation_path, args, kc)
        if tool.target_exe is None:
            message = f'Could not find {tool_type} executable. ' \
                'Please set the installation path in jupyterlab-nvidia-nsight extension settings'
            self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
            self.finish(json.dumps({'message': message}))
            return
        warning = await tool.check()
        old_tool = pending_restart_kernel_id_to_nsight_tool.pop(kernel_id, None)
        if old_tool is not None:
            old_tool.cleanup()
        pending_restart_kernel_id_to_nsight_tool[kernel_id] = tool
        self.finish(json.dumps({'warning': warning}))


class DoDisableHandler(HandlerBase):
    def post_impl(self, *, kernel_id: str):
        tool = pending_restart_kernel_id_to_nsight_tool.pop(kernel_id, None)
        if tool is not None:
            tool.cleanup()
        pending_restart_kernel_id_to_nsight_tool[kernel_id] = None
        self.finish()


class DoStartHandler(HandlerBase):
    async def post_impl(self, *, kernel_id: str, report_path: str, args: str):
        tool = kernel_id_to_nsight_tool.get(kernel_id)
        if tool is None:
            self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
            self.finish(json.dumps({'message': 'Could not find tool'}))
            return
        await tool.start(report_path, args)
        self.finish()


class DoStopHandler(HandlerBase):
    async def post_impl(self, *, kernel_id: str, args: str):
        tool = kernel_id_to_nsight_tool.get(kernel_id)
        if tool is None:
            self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
            self.finish(json.dumps({'message': 'Could not find tool'}))
            return
        self.finish(json.dumps(await tool.stop(args)))


class DoStartWebRTCHandler(HandlerBase):
    async def post_impl(self, *, report_path: str, tool_type: str,
                        max_resolution: Optional[str] = None, host: Optional[str] = None,
                        allowed_http_ports: str = '', allowed_media_ports: str = '',
                        turn_host: str = '', turn_port: int = 3478,
                        turn_username: str = '', turn_password: str = '', image_name: str = ''):
        server_app = ServerApp.instance()
        host = host or server_app.ip
        if host == '0.0.0.0':
            host = socket.gethostname()
        if not turn_host:
            turn_port = 0
        try:
            port = await WebRTCManager.run(tool_type, NsightTool.normalize_path(report_path), host,
                                           max_resolution, self.parse_ports(allowed_http_ports),
                                           self.parse_ports(allowed_media_ports),
                                           turn_host, turn_port, turn_username, turn_password,
                                           image_name)
            if port is None:
                self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
                self.finish(json.dumps({'message': 'Failed to start WebRTC container'}))
            else:
                protocol = 'https' if server_app.certfile and server_app.keyfile else 'http'
                self.finish(json.dumps({'port': port, 'url': f'{protocol}://{host}:{port}'}))
        except Exception as e:
            self.set_status(HTTPStatus.INTERNAL_SERVER_ERROR.value)
            self.finish(json.dumps({'message': repr(e)}))

    @staticmethod
    def parse_ports(ports: str):
        """Parse the ports string into a set of ports.
        The input format is a comma separated items,
        where each item can be a single numeric port or a range.
        Where a range is denoted as <port1>-<portN>.
        """
        res = set()
        if not ports:
            return res
        for item in ports.split(','):
            if '-' in item:
                start, end = map(int, item.split('-', 1))
                if start > end:
                    raise ValueError(f"Invalid port range: {item}")
                if start < MIN_PORT or end > MAX_PORT:
                    raise ValueError(f"Invalid port range: {item}. "
                                     f"Port numbers must be between {MIN_PORT} and {MAX_PORT}")
                if start == end:
                    res.add(start)
                else:
                    res.update(range(start, end + 1))
            else:
                port = int(item)
                if MIN_PORT <= port <= MAX_PORT:
                    res.add(port)
                else:
                    raise ValueError(f"Invalid port number: {item}. "
                                     f"Port numbers must be between {MIN_PORT} and {MAX_PORT}")
        return res


class DoStopWebRTCHandler(HandlerBase):
    def post_impl(self, *, report_path: str):
        WebRTCManager.stop(NsightTool.normalize_path(report_path))
        self.finish()


class DoIsWebRTCPulledHandler(HandlerBase):
    def post_impl(self, *, tool_type: str):
        try:
            WebRTCManager.get_docker_image(WebRTCManager.get_docker_client(), tool_type)
            self.finish(json.dumps({'pulled': True}))
        except docker.errors.ImageNotFound as e:
            self.finish(json.dumps({'pulled': False, 'message': e.explanation}))


class DoPullWebRTCHandler(HandlerBase):
    def post_impl(self, *, tool_type: str):
        WebRTCManager.pull_image(tool_type)
        self.finish()


def setup_handlers(web_app):
    base_route_pattern = url_path_join(web_app.settings['base_url'], 'jupyterlab-nvidia-nsight')
    handlers = [
        (url_path_join(base_route_pattern, name), handler)
        for name, handler in (
            ('is-inside-docker', DoIsInsideDockerHandler),
            ('enable', DoEnableHandler),
            ('disable', DoDisableHandler),
            ('start', DoStartHandler),
            ('stop', DoStopHandler),
            ('start-webrtc', DoStartWebRTCHandler),
            ('stop-webrtc', DoStopWebRTCHandler),
            ('is-webrtc-pulled', DoIsWebRTCPulledHandler),
            ('pull-webrtc', DoPullWebRTCHandler),
            ('get-kernel-state', DoGetKernelStateHandler),
        )
    ]
    web_app.add_handlers('.*$', handlers)
    wrap_kernel_provisioner_factory()
