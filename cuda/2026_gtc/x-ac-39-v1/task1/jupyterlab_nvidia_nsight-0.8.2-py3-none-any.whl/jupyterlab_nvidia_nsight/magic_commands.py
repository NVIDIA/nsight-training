# from string import Template


# magic_template = Template("""
import subprocess
from abc import ABC, abstractmethod
from IPython.core.magic import Magics, magics_class, line_cell_magic
from IPython import get_ipython
from IPython.core.async_helpers import get_asyncio_loop
import shlex
import tempfile
from pathlib import Path
import shutil
import re
from datetime import datetime
import functools
import asyncio

from ipykernel import get_connection_file
from urllib.parse import urljoin
import requests
from typing import List, Optional, Tuple


class NsightTool(ABC):
    def __init__(self, kernel_id: str, installation_path: str, args: str):
        self.kernel_id = kernel_id
        self.installation_path = installation_path
        self.args = shlex.split(args)
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.tmp_report_path = Path(self.tmp_dir.name) / f'tmp_report.{self.target_exe_name()}-rep'
        self.target_exe = shutil.which(self.target_exe_name(), path=self.target_exe_dir())
        self.start_args: Optional[Tuple[Path, str]] = None

    def cleanup(self):
        self.tmp_dir.cleanup()

    def check(self) -> Optional[str]:
        version = subprocess.check_output([self.target_exe, '--version']).decode('utf-8').strip()
        self.check_version(version)
        subprocess.check_call([self.launch_kernel_cmd(), '--help'])

    def start(self, report_path: str, args: str):
        if self.start_args is not None:
            return
        report_path = self.normalize_path(report_path)
        self.start_args = report_path, args
        try:
            self.check_output_directory()
            self.do_start()
        except Exception:
            self.start_args = None
            raise

    def stop(self):
        if self.start_args is None:
            return
        output = self.do_stop()
        self.start_args = None
        return output

@magics_class
class NsightMagics(Magics):
    server_url = "$server_url"
    server_token = "$server_token"

    @line_cell_magic
    def nsys(self, line, cell=None):
        return self._tool_magic_impl("nsys", line, cell)

    @line_cell_magic
    def ncu(self, line, cell=None):
        return self._tool_magic_impl("ncu", line, cell)

    def _tool_magic_impl(self, tool_type: str, line, cell=None):
        return (
            self._tool_line_magic_impl(tool_type, line)
            if cell is None
            else self._tool_cell_magic_impl(tool_type, line, cell)
        )

    def _tool_line_magic_impl(self, tool_type: str, line: str):
        cmd, *args = shlex.split(line)
        if cmd == "enable":
            return self._enable(tool_type, args)
        elif cmd == "disable":
            return self._disable(tool_type)
        elif cmd == "start":
            return self._start(tool_type, args)
        elif cmd == "stop":
            return self._stop()
        else:
            raise ValueError(f"Invalid command: {cmd}")

    def _tool_cell_magic_impl(self, tool_type: str, line: str, cell: str):
        pass

    def _enable(self, tool_type: str, args: List[str]):
        self._send_request(
            "enable",
            {
                "kernel_id": self._kernel_id,
                "tool_type": tool_type,
                "args": shlex.join(args),
            },
        )
        return (
            f"Nsight {'Systems' if tool_type == 'nsys' else 'Compute'} is now enabled. "
            "Restart the kernel to apply the changes."
        )

    def _disable(self, tool_type: str):
        self._send_request("disable", {"kernel_id": self._kernel_id})
        return (
            f"Nsight {'Systems' if tool_type == 'nsys' else 'Compute'} is now disabled. "
            "Restart the kernel to apply the changes."
        )

    def _start(self, tool_type: str, args: List[str]):
        self._send_request(
            "start",
            {
                "kernel_id": self._kernel_id,
                "args": shlex.join(args),
                "report_path": self._generate_report_name(tool_type),
            },
        )

    def _stop(self):
        return self._send_request("stop", {"kernel_id": self._kernel_id})

    def _profile(self, tool_type: str, args: List[str], cell: str):
        self._send_request(
            "start",
            {
                "kernel_id": self._kernel_id,
                "tool_type": tool_type,
                "args": shlex.join(args),
                "report_path": self._generate_report_name(tool_type),
            },
        )
        self.shell.run_cell(cell)
        self._send_request("stop", {"kernel_id": self._kernel_id})

    def _send_request(self, request: str, json=None):
        async def _send_request_async(self, request: str, json=None):
            if json is None:
                json = {}
            response = await asyncio.to_thread(
                requests.post,
                urljoin(self.server_url, f"jupyterlab-nvidia-nsight/{request}"),
                params={"token": self.server_token},
                json=json,
            )
            response.raise_for_status()
            return response.json() if response.content else None

        return asyncio.run_coroutine_threadsafe(
            _send_request_async(request, json), get_asyncio_loop()).result()

    @functools.cached_property
    def _kernel_id(self):
        # Extract kernel ID from connection file name (format: kernel-{kernel_id}.json)
        # This matches the kernel ID used by JupyterLab frontend
        connection_file = get_connection_file()
        match = re.search(r"kernel-(.+)\\.json$$", connection_file)
        if match:
            return match.group(1)
        raise RuntimeError("Could not find the kernel ID")

    def _generate_report_name(self, tool_type: str):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return f"report_{self._kernel_id}_{timestamp}.{tool_type}-rep"


get_ipython().register_magics(NsightMagics)
# """)
